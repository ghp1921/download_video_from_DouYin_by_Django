const axios = require('axios');
const fs = require('fs');
const path = require('path');

class Program {
  constructor(pageUrl, filePath = "download") {
    this.start(pageUrl, filePath);
  }

  async start(pageUrl, filePath) {
    // 从页面URL中提取视频ID并拼接到video_url上
    const videoId = pageUrl.split('/video/')[-1].split('?')[0];
    const url = `https://www.douyin.com/aweme/v1/web/aweme/detail/?device_platform=webapp&aweme_id=${videoId}`;

    try {
      const response = await axios.get(url, { headers: headers });
      const resource = response.data;

      // 从响应数据中提取视频源地址和视频标题
      const bitRates = resource.aweme_detail.video.bit_rate;
      const spDescribe = resource.aweme_detail.desc;

      let spUrl = null;
      for (const bitRate of bitRates) {
        const playUrls = bitRate.play_addr.url_list;
        if (playUrls && playUrls.length > 0) {
          spUrl = playUrls[0];
          break;
        }
      }

      if (!spUrl) {
        console.error('无法找到视频源地址');
        return;
      }

      // 下载视频
      const videoResponse = await axios.get(spUrl, { headers: headers });
      const videoContent = videoResponse.data;

      const filePath = path.join(filePath, `${spDescribe}.mp4`);
      fs.writeFileSync(filePath, videoContent);

      console.log('success!');
      console.log(`已下载到本地: ${filePath}`);
    } catch (error) {
      console.error('发生错误:', error);
    }
  }
}

// 使用示例
const program = new Program('https://www.douyin.com/video/7332410434978401555?modeFrom=');