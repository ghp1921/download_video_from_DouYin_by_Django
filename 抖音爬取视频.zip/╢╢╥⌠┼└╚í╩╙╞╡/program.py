import json
import time
from alive_progress import alive_bar
import requests
from headers import headers



class Program:
    video_url = 'https://www.douyin.com/aweme/v1/web/aweme/detail/?device_platform=webapp&aweme_id='

    def __init__(self, page_url, file_path="download"):
        self.start(page_url, file_path)

    def start(self, page_url, file_path):
        # 将视频id从sp_url分离并且拼接到video_url上
        # eg: https://www.douyin.com/video/7332410434978401555?modeFrom=
        url = self.video_url + (page_url.split('/video/')[-1]).split('?')[0]

        # 根据拼接出的页面url发起请求，解析出视频url
        print('发起请求')
        re = requests.request(url=url, headers=headers, method='GET')
        content = re.text
        resource = json.loads(content)
        # print(type(resource))
        # print(resource)
        print('开始解析')

        # 视频源地址
        bit_rate = resource['aweme_detail']['video']['bit_rate']
        # print(bit_rate)
        print('解析视频源url')


        # 视频标题
        sp_describe = resource['aweme_detail']['desc']
        # print(sp_describe)
        print('解析视频标题')

        play_urls = []
        for play_addr in bit_rate:
            play_urls.append(play_addr['play_addr']['url_list'])

        # 会得到视频的各个版本，默认选择第一个下载
        sp_url = play_urls[0][0]
        # print(tmp_url)

        # 开始下载
        print('请求视频资源')
        time.sleep(2)
        sp_item = requests.request(url=sp_url,headers=headers, method='GET')
        sp_content = sp_item.content
        print('正在下载视频')
        path = str(file_path+'/'+sp_describe+'.mp4')
        with open(path,'wb') as f:
            f.write(sp_content)
        print('success!')
        print('已下载到本地:'+path)


def test():
    p = Program("https://www.douyin.com/video/7335470692428745999?modeFrom=userPost&secUid=MS4wLjABAAAArYKPNMMD1jl-9NRYvTr7HlYbVJOqn9hpwqVS6TNdAusAaA5XxVm6TNRaAqQVkk4x", )

# test()



def test():
    p = Program("https://www.douyin.com/video/7335470692428745999?modeFrom=userPost&secUid=MS4wLjABAAAArYKPNMMD1jl-9NRYvTr7HlYbVJOqn9hpwqVS6TNdAusAaA5XxVm6TNRaAqQVkk4x", )

# test()
