from program import Program


def main(url, file_path):
    if file_path == "":
        p = Program(page_url=url)
    else:
        p = Program(page_url=url, file_path=file_path)


if __name__ == '__main__':
    url = input("请输入抖音视频详情页url：")

    # 个人设置下载位置::默认在download文件夹下
    # file_path = ""
    file_path = ""

    # 开始执行函数
    main(url, file_path)
