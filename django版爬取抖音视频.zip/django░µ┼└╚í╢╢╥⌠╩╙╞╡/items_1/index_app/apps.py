from django.apps import AppConfig


class IndexAppConfig(AppConfig):
    name = 'index_app'
