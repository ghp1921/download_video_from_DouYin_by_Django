from django.shortcuts import render
from django.http import JsonResponse
import json
import time
from alive_progress import alive_bar
import requests


headers = {
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Referer':'https://www.douyin.com/user/MS4wLjABAAAArYKPNMMD1jl-9NRYvTr7HlYbVJOqn9hpwqVS6TNdAusAaA5XxVm6TNRaAqQVkk4x',
    'Cookie':"douyin.com; device_web_cpu_core=12; device_web_memory_size=8; architecture=amd64; __ac_nonce=065cddccc00298ac87a8d; __ac_signature=_02B4Z6wo00f0136rPnwAAIDDF6QEJdeUPid-izrAALpye3; ttwid=1%7CLuxMlyWhO1-U0YG5Ab00euwlO_H3ySI8GDMe5FNDly0%7C1707990220%7C724842b9eebeaa75a77b9194c0bd9fa23ee05ada3152f197fd04e94c56b95cf0; home_can_add_dy_2_desktop=%220%22; dy_swidth=1536; dy_sheight=864; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1536%2C%5C%22screen_height%5C%22%3A864%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A12%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A150%7D%22; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%7D; csrf_session_id=c3af1a83c1767794a84fcf50a92ef15b; strategyABtestKey=%221707990224.569%22; download_guide=%220%2F%2F1%22; passport_csrf_token=f6bb94977738939dfb10d1d4bcdfc2fc; passport_csrf_token_default=f6bb94977738939dfb10d1d4bcdfc2fc; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCQU1xcktsdEVTRVpWazRGVCtwUnY0S2FlZng4NEFoek1hM1E2cm5mSHFFbzFoRFNVZmZzdkZPU1JsUThKQlNJaDZtYWVGMWUyZS9UL2Z5R1BPSStDZjA9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; bd_ticket_guard_client_web_domain=2; msToken=I55_Y3HjGXf0MqINZglD8M3CQmlanm0DlhD4MvTSVv-RRN7MEMB-f1gfoGwsJwzd67dcQD3-IMBMeimLn0NVvhR_SiOHw8UOpc1bkpg=; msToken=NGe1buAu1w7zqGaVFk77yzQ4N-KmS333R8FzLF3z9bqfUAeHCB-CqMlqPmM9qTn7Ff4x6kNuYYAU9TEIcke1mywJ8CoO89JhkqitMpbqKSqHUaQ7; IsDouyinActive=false"
}


class Program:
    result ={}
    video_url = 'https://www.douyin.com/aweme/v1/web/aweme/detail/?device_platform=webapp&aweme_id='

    def __init__(self, page_url,):
        self.start(page_url)

    def start(self, page_url ):
        # 将视频id从sp_url分离并且拼接到video_url上
        # eg: https://www.douyin.com/video/7332410434978401555?modeFrom=
        url = self.video_url + (page_url.split('/video/')[-1]).split('?')[0]

        # 根据拼接出的页面url发起请求，解析出视频url
        print('发起请求')
        re = requests.request(url=url, headers=headers, method='GET')
        content = re.text
        resource = json.loads(content)
        # print(type(resource))
        # print(resource)
        print('开始解析')

        # 视频源地址
        bit_rate = resource['aweme_detail']['video']['bit_rate']
        # print(bit_rate)
        print('解析视频源url')

        # 视频标题
        sp_describe = resource['aweme_detail']['desc']
        # print(sp_describe)
        print('解析视频标题')

        play_urls = []
        for play_addr in bit_rate:
            play_urls.append(play_addr['play_addr']['url_list'])

        # 会得到视频的各个版本，默认选择第一个下载
        sp_url = play_urls[0][0]
        # print(tmp_url)

        name = str(sp_describe + '.mp4')

        self.result = {
            'name': name,
            'url': sp_url,
        }

# Create your views here.
def show_index(request):
    return render(request, 'index.html')




def get_url(request):
    url = request.GET.get('url')
    print('取到url：',url)
    p = Program(page_url=url)
    # print(p.result)
    data = p.result
    return JsonResponse(data)
